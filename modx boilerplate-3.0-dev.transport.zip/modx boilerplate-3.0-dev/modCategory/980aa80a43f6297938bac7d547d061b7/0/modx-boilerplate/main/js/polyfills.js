// place any Polyfills in here, instead of separate, slower script files.

$(document).ready(function() {
	
});