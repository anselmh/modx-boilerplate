<?php
/**
 * Define the MODX path constants necessary for core installation
 *
 * @package eventsx
 * @subpackage build
 */
define('MODX_CORE_PATH', $_SERVER['DOCUMENT_ROOT'].'/core/');
define('MODX_CONFIG_KEY','config');